# ILT Strategy: Feedback That Lands

**Turning Performance Conversations Into Results**
*45-Minute Instructor-Led Training | Lunch & Learn Format*

---

## Why This Topic

The performance gap is specific: managers and team leads at Meridian Solutions — a fictional 200-person professional services firm used as the portfolio context — know feedback is expected. Most can articulate what good feedback looks like. Few deliver it when the moment arrives, and when they do, the conversation either collapses into reassurance or escalates into defensiveness. The result is a silent performance tax: issues persist, resentment accumulates, and formal PIPs arrive too late.

Training is the right intervention here — not because feedback is purely a knowledge problem, but because managers lack practiced fluency in the skill. This is a performance gap with a behavioral root cause, and behavioral change requires practice under realistic conditions.

ILT is the right modality because feedback is fundamentally relational. Watching a scenario on a screen does not build the muscle memory that comes from having an uncomfortable conversation in front of peers, noticing the impulse to soften the message, and finishing it anyway. The activity design depends on this.

A 45-minute lunch and learn is the minimum viable format: long enough for structured practice, short enough for voluntary attendance, low-threat enough for honest engagement.

---

## Project Charter

**Course Title:** Feedback That Lands: Turning Performance Conversations Into Results
**Version:** 1.0
**Format:** Instructor-Led Training (Lunch & Learn)
**Seat Time:** 45 minutes
**Modality:** In-person (adaptable to virtual facilitation)
**Deliverable Set:** Instructor Guide · Participant Guide · Participant Workbook · PowerPoint Deck (16:9) · Job Aid

### Client / Sponsor

| Role              | Name (Fictional)                    |
| ----------------- | ----------------------------------- |
| Organization      | Meridian Solutions                  |
| Sponsor           | VP of People & Culture              |
| Primary SME       | Senior Director, Talent Development |
| ID / Project Lead | Adam Leibler                        |

### Problem Statement

Managers at Meridian Solutions are not delivering feedback at the frequency or quality that the organization requires for performance management to function. Exit and stay interviews from the past 12 months identify "unclear expectations" and "no feedback" as top-three contributing factors to disengagement. Quarterly manager effectiveness survey scores for "provides actionable feedback" sit at 51% favorable — 17 points below the industry benchmark.

### Scope

**In scope:**

- How to structure a feedback conversation (Situation-Behavior-Impact model)
- Recognizing and managing the impulse to soften, avoid, or overload feedback
- One scenario-based practice conversation conducted in pairs
- One job aid for post-training reference

**Out of scope:**

- Performance improvement plans and disciplinary procedures
- Written feedback or documentation requirements
- 360 feedback tools and processes
- Coaching, mentoring, and ongoing development conversations

### Constraints & Assumptions

- 45-minute hard stop; group arrives from lunch, attendance is voluntary
- Facilitator is an internal HR business partner with moderate facilitation skills — not a certified trainer
- No LMS for post-training follow-up; the job aid is the primary retention tool
- Learners have at least one direct report and have managed for 12+ months
- Group size: 8–20 participants per session

### Success Metrics

| Metric                                                  | Measurement Method                     | Target               |
| ------------------------------------------------------- | -------------------------------------- | -------------------- |
| Manager feedback frequency (direct report self-report)  | Pulse survey at 30 days                | +20% favorable shift |
| Manager effectiveness survey (actionable feedback item) | Next quarterly cycle                   | 51% → 65%+           |
| Facilitator confidence rating                           | Post-session self-report               | 4/5 or higher        |
| Participant satisfaction                                | End-of-session response card (3 items) | 4/5 or higher        |

### Project Timeline

| Phase          | Duration  | Notes                                       |
| -------------- | --------- | ------------------------------------------- |
| Needs Analysis | 1 week    | Desk research + 2 stakeholder interviews    |
| Design         | 1 week    | Design document drafted, reviewed, approved |
| Development    | 2 weeks   | All materials; one round of SME review      |
| Pilot          | 1 session | 6–8 internal volunteers                     |
| Revision       | 3 days    | Based on pilot debrief                      |
| Launch         | Rolling   | HRBP delivers in department cohorts         |

---

## Needs Analysis

### Performance Gap Analysis

**Is State (Current Performance)**
Managers are providing feedback informally, inconsistently, and predominantly in positive or neutral registers. When performance issues arise, the default response is to wait — for the next 1:1, for the next review cycle, for the issue to self-correct. When feedback is delivered, it lacks specificity: observable behavior and concrete impact are absent. The message is either so cushioned it doesn't land, or so blunt the relationship absorbs the damage.

**Should State (Target Performance)**
Managers recognize a performance moment, structure a brief and specific feedback conversation using observable behavior and concrete impact, deliver it within 48 hours of the triggering event, and follow up once to confirm understanding.

**Gap Statement**
Managers possess surface-level knowledge of what effective feedback looks like. They lack practiced fluency in delivering it under the discomfort of a real moment.

### Root Cause Analysis

Using Mager & Pipe's performance analysis framework:

| Root Cause Category | Finding                                                                 | Implication                                                                                  |
| ------------------- | ----------------------------------------------------------------------- | -------------------------------------------------------------------------------------------- |
| Knowledge / Skill   | Managers know the concept; lack practiced delivery                      | Training is the appropriate intervention                                                     |
| Motivation          | Avoidance driven by discomfort, not disagreement with feedback's value  | Training must normalize discomfort, not only build skill                                     |
| Environment         | No structured leadership expectation for feedback outside review cycles | Companion recommendation: VP-level accountability expectation (out of scope for this course) |
| Resources           | No simple framework or job aid available in the moment                  | Job aid included in deliverables                                                             |

**Training gap confirmed.** A skill-fluency gap with a discomfort/avoidance component. Training addresses the skill; leadership expectation-setting addresses the motivational-environmental dimension.

### Audience Analysis

**Primary Learners:** People managers with at least one direct report; 12+ months of management experience; professional services background with high literacy and comfort with frameworks; mixed motivation (some self-selected, some encouraged by HRBP); low-to-moderate comfort with role play — requires explicit framing.

**Secondary Audience (Facilitator):** Internal HRBPs. The Instructor Guide must anticipate resistance to the practice activity and provide specific language for reframing it.

### Task Analysis

**Critical Task:** Deliver a feedback conversation using observable behavior and concrete impact, without over-softening or over-correcting.

**Task Breakdown:**

1. Recognize the performance moment (timing and trigger identification)
2. Select the right structure (SBI: Situation, Behavior, Impact)
3. Open with intent clarity: "I want to give you some feedback about X"
4. State the specific behavior (observable, not inferential)
5. State the impact (on team, project, client, or relationship)
6. Pause and listen
7. Reach a forward-looking agreement
8. Follow up once within a defined period

### Environmental Analysis

- Sessions take place during lunch; time is compressed and participants are transitioning from other work
- Physical space varies; no guarantee of privacy
- Virtual delivery option may be needed for distributed teams
- Post-training environment has no LMS reinforcement — job aid is the only sustained retention tool

---

## Design Document

### Terminal Learning Objective

Given a realistic performance scenario and the opportunity for a practice conversation, managers will conduct a feedback conversation using the SBI structure, stating specific observable behavior and concrete impact, without softening the central message.

### Enabling Learning Objectives

1. Distinguish between observations (behavior) and inferences (character) in a feedback statement.
2. Apply the Situation-Behavior-Impact model to structure a feedback conversation.
3. Identify the two primary derailing patterns — over-softening and overloading — and name the correction for each.
4. Deliver a 60-second feedback statement on a given scenario in a practice pair.
5. Use the job aid to prepare for a real feedback conversation within two weeks of the session.

### Course Structure and Agenda

| Time      | Segment                       | Instructional Strategy                    | Key Content                                                                                                                        |
| --------- | ----------------------------- | ----------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------- |
| 0:00–0:05 | Opening and framing           | Direct instruction                        | Survey data as the entry point; course scope; session promise; time commitment named explicitly                                    |
| 0:05–0:12 | The observation/inference gap | Pair discussion + group share             | "She missed the deadline" (behavior) vs. "She's disorganized" (inference); participants classify four examples                     |
| 0:12–0:22 | SBI framework                 | Direct instruction + group reconstruction | Facilitator models a weak SBI, then a strong one; group reconstructs the failed example using SBI                                  |
| 0:22–0:35 | Scenario practice             | Paired practice                           | Scenario cards distributed; one participant gives feedback, one receives; 3-minute conversation; structured debrief using workbook |
| 0:35–0:42 | Full-group debrief            | Facilitated discussion                    | What landed? Where did it get hard? Facilitator surfaces the over-softening pattern with Instructor Guide language                 |
| 0:42–0:45 | Closing and transfer          | Direct instruction                        | One real-conversation commitment named aloud; job aid walkthrough; digital version QR code                                         |

### Instructional Strategy Principles

**Principle 1: Primacy of practice.** The conversation practice is the course. Everything before it is activation and setup. Everything after it is reflection and transfer. The framework teaches in 10 minutes; the practice teaches in 13.

**Principle 2: Discomfort as data.** The opening must normalize discomfort without resolving it. Managers who know feedback is uncomfortable and still avoid it don't need reassurance — they need a practiced pathway through it.

**Principle 3: Facilitator credibility over content volume.** The IG must give the HRBP facilitator specific language for every anticipated derailment: "this is too prescriptive," "my team is different," "I already do this." These are avoidance in disguise, not content objections. The facilitator must recognize and name them without escalating.

### Assessment Strategy

**Formative:** Observation/inference sorting exercise (ELO 1); group SBI reconstruction (ELO 2, 3); paired practice with structured workbook debrief (ELO 4).

**Transfer Evaluation (Level 3):** 30-day pulse survey to direct reports — single item, 5-point scale: *"My manager has provided me with specific, actionable feedback in the past 30 days."*

**Summative:** No formal post-test. This is a skill session, not a knowledge check. Evaluation lives in the 30-day pulse and the next quarterly manager effectiveness cycle.

---

## Deliverables Map

| Deliverable          | Format                           | Primary Audience           | Purpose                                                                                                     |
| -------------------- | -------------------------------- | -------------------------- | ----------------------------------------------------------------------------------------------------------- |
| Instructor Guide     | .docx                            | HRBP facilitator           | Full facilitation script, timing notes, objection-handling language, debrief questions, setup and logistics |
| Participant Guide    | .docx (1-page)                   | Participants               | SBI model reference, observation/inference contrast, session agenda                                         |
| Participant Workbook | .docx (print)                    | Participants               | Scenario cards, practice debrief worksheet, job aid section                                                 |
| PowerPoint Deck      | .pptx (16:9)                     | Displayed during session   | Agenda, activity slides, SBI visual, debrief prompts — no more than 10 slides                               |
| Job Aid              | .pdf (laminated card or digital) | Participants, post-session | SBI framework, derailing patterns and corrections, pre-conversation checklist                               |

---

*Document version 2.1 | Portfolio: Instructional Design | Adam Leibler*
